//
//  ProfileVC.swift
//  CU Find it!
//
//  Created by Richard Gu on 11/21/21.
//

import UIKit

class ProfileVC: UIViewController{
    
    let mainTitle = UILabel()
    let userName = UILabel()
    let profilePic = UIImageView()
    let recentFindsLabel = UILabel()
    let recentLostLabel = UILabel()
    
    private let cellPadding: CGFloat = 20
    
    //set up recent finds and losts
    private var recentFindsView: UICollectionView!
    
    private var recentLostsView: UICollectionView!
    private var recentFinds: [Item] = []
    private var recentLosts: [Item] = []
    
    func appendFinds(item: Item){
        recentFinds.append(item)
    }
    
    func appendLosts(item: Item){
        recentLosts.append(item)
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .systemBackground
        
        
        var itemNumberOne = Item(imageName: "socks", name: "Blue Sock", location: "Donlon Lounge", dateFound: "2d", idFound: "ld386", idClaimed: "", id: 1)
        appendFinds(item: itemNumberOne)
        var itemNumberTwo = Item(imageName: "iphone", name: "iphone", location: "Donlon Lounge", dateFound: "2d", idFound: "ld386", idClaimed: "", id: 1)
        appendFinds(item: itemNumberTwo)
        var itemNumberThree = Item(imageName: "socks", name: "Blue Sock", location: "Donlon Lounge", dateFound: "2d", idFound: "ld386", idClaimed: "", id: 1)
        appendFinds(item: itemNumberThree)
        var itemNumberFour = Item(imageName: "iphone", name: "iphone", location: "Donlon Lounge", dateFound: "2d", idFound: "ld386", idClaimed: "", id: 1)
        appendFinds(item: itemNumberFour)
        var itemNumberFive = Item(imageName: "socks", name: "Blue Sock", location: "Donlon Lounge", dateFound: "2d", idFound: "ld386", idClaimed: "", id: 1)
        appendFinds(item: itemNumberFive)
        
        let textAttributes = [NSAttributedString.Key.foregroundColor:UIColor.black]
        navigationController?.navigationBar.titleTextAttributes = textAttributes
        
        //collection views stuff
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = cellPadding
        layout.minimumInteritemSpacing = cellPadding
        recentFindsView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        recentFindsView.backgroundColor = .clear
        recentFindsView.translatesAutoresizingMaskIntoConstraints = false
        recentFindsView.clipsToBounds = true
        recentFindsView.register(ItemsCollectionViewCell.self, forCellWithReuseIdentifier: "cell")
        recentFindsView.showsHorizontalScrollIndicator = false
        recentFindsView.dataSource = self
        recentFindsView.delegate = self
        view.addSubview(recentFindsView)
        
        //other stuff
        
        mainTitle.font = .systemFont(ofSize: 18, weight: .black)
        mainTitle.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(mainTitle)
        
        //username label
        userName.text = ""
        userName.textColor = .black
        
        userName.font = .systemFont(ofSize: 18, weight: .black)
        userName.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(userName)
        
        //profilePic init
        profilePic.image = UIImage(named: "user-image")
        profilePic.backgroundColor = .blue
        profilePic.contentMode = .scaleAspectFill
        profilePic.clipsToBounds = true
        profilePic.layer.cornerRadius = 10
        profilePic.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(profilePic)
        
        //recent finds label
        recentFindsLabel.text = "Claims"
        recentFindsLabel.textColor = .black
        
        recentFindsLabel.font = .systemFont(ofSize: 25, weight: .bold)
        recentFindsLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(recentFindsLabel)
        
        //recent lost label
        recentLostLabel.text = ""
        recentLostLabel.textColor = .black
        
        recentLostLabel.font = .systemFont(ofSize: 25, weight: .bold)
        recentLostLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(recentLostLabel)
    
    NSLayoutConstraint.activate([
//        mainTitle.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor, constant: 0),
//        mainTitle.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 0),
//
//        userName.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 120),
//        userName.topAnchor.constraint(equalTo: mainTitle.bottomAnchor, constant: 15),
        
        profilePic.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
        profilePic.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
        //profilePic.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 0),
        profilePic.heightAnchor.constraint(equalToConstant: 100),
        profilePic.widthAnchor.constraint(equalToConstant: 100),
        
        
        recentFindsLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
        recentFindsLabel.topAnchor.constraint(equalTo: profilePic.bottomAnchor, constant: 20),
        recentFindsLabel.bottomAnchor.constraint(equalTo: profilePic.bottomAnchor, constant: 40),
        
        recentFindsView.topAnchor.constraint(equalTo: recentFindsLabel.bottomAnchor, constant: 10),
        recentFindsView.bottomAnchor.constraint(equalTo: recentFindsLabel.bottomAnchor, constant: 220),
        recentFindsView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: -20),
        recentFindsView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: 20),
        

        
        
        recentLostLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
        recentLostLabel.topAnchor.constraint(equalTo: recentFindsView.bottomAnchor, constant: 60),
        
        
        
    ])
    
    }
}

extension ProfileVC: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! ItemsCollectionViewCell
            
        var item: Item

        item = recentFinds[indexPath.item]
            cell.configure(for: item)
            return cell
            
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return recentFinds.count
    }
}

    extension ProfileVC: UICollectionViewDelegateFlowLayout, UICollectionViewDelegate {

        func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
            let item = recentFinds[indexPath.item]
            if let cell = collectionView.cellForItem(at: indexPath) as? ItemsCollectionViewCell {
                let vc = SpecificItemViewController(item: item)
                vc.view.backgroundColor = .white
                //vc.delegate = self
                navigationController?.pushViewController(vc, animated: true)
                
            }
        }
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            
            if (collectionView == recentFindsView) {
                let numItemsPerRow: CGFloat = 3.0
                let size = (collectionView.frame.width - cellPadding) / numItemsPerRow
                return CGSize(width: size, height: size*1.4)
            } else {
                let fatness = 150
                let tallness = 35
                return CGSize(width: fatness, height: tallness)
            }
            
        }
        
        func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
            
        }

    }


