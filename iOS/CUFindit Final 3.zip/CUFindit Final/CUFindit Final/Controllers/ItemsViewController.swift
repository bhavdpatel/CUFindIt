//
//  ItemsViewController.swift
//  CUFindit Final
//
//  Created by Liam Du on 12/3/21.
//

import UIKit

class ItemsViewController: UIViewController, UISearchResultsUpdating, UISearchBarDelegate {
    
    //declare colelctionview
    private var itemCollectionView: UICollectionView!
    //declare search bar
    private let searchController = UISearchController(searchResultsController: nil)
    //add button
    private var addButton = UIButton(frame: CGRect(x: 0, y: 0, width: 82, height: 82))
    //the array for the collectionview of lists
    private var items: [Item] = []
    //the array for the filtered items
    private var filteredItems = [Item]()
    //idk some random shit
    private let itemCellReuseIdentifier = "itemCellReuseIdentifier"
    private let cellPadding: CGFloat = 20
    //i made this function to append those items to the array (including the ones you got from backend)
    func appendItems(item: Item){
        items.append(item)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        
        //changing refresh color to teal
        let refreshControl = UIRefreshControl()
        refreshControl.tintColor = .systemTeal
        
        NetworkManager.getAllItem { items in
            self.items = items
            self.itemCollectionView.reloadData()
        }
        
        //making some instances of the Item (for networks, I think you will decode JSON files and make more variables from the JSON data
        var itemNumberOne = Item(imageName: "socks", name: "Blue Sock", location: "Donlon Lounge", dateFound: "2d", idFound: "ld386", idClaimed: "", id: 1)
        appendItems(item: itemNumberOne)
        var itemNumberTwo = Item(imageName: "iphone", name: "iphone", location: "Donlon Lounge", dateFound: "2d", idFound: "ld386", idClaimed: "", id: 1)
        appendItems(item: itemNumberTwo)
        var itemNumberThree = Item(imageName: "socks", name: "Blue Sock", location: "Donlon Lounge", dateFound: "2d", idFound: "ld386", idClaimed: "", id: 1)
        appendItems(item: itemNumberThree)
        var itemNumberFour = Item(imageName: "iphone", name: "iphone", location: "Donlon Lounge", dateFound: "2d", idFound: "ld386", idClaimed: "", id: 1)
        appendItems(item: itemNumberFour)
        var itemNumberFive = Item(imageName: "socks", name: "Blue Sock", location: "Donlon Lounge", dateFound: "2d", idFound: "ld386", idClaimed: "", id: 1)
        appendItems(item: itemNumberFive)
        var itemNumberSix = Item(imageName: "iphone", name: "iphone", location: "Donlon Lounge", dateFound: "2d", idFound: "ld386", idClaimed: "", id: 1)
        appendItems(item: itemNumberSix)
        var itemNumberSeven = Item(imageName: "socks", name: "Blue Sock", location: "Donlon Lounge", dateFound: "2d", idFound: "ld386", idClaimed: "", id: 1)
        appendItems(item: itemNumberSeven)
        var itemNumberEight = Item(imageName: "iphone", name: "iphone", location: "Donlon Lounge", dateFound: "2d", idFound: "ld386", idClaimed: "",id: 1)
        appendItems(item: itemNumberEight)
        var itemNumberNine = Item(imageName: "socks", name: "Blue Sock", location: "Donlon Lounge", dateFound: "2d", idFound: "ld386", idClaimed: "", id: 1)
        appendItems(item: itemNumberNine)
        var itemNumberTen = Item(imageName: "iphone", name: "iphone", location: "Donlon Lounge", dateFound: "2d", idFound: "ld386", idClaimed: "", id: 1)
        appendItems(item: itemNumberTen)
        
        //setting up the search bar
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "What did you lose?"
        navigationItem.searchController = searchController
        
        //idk wtf this is
        let textAttributes = [NSAttributedString.Key.foregroundColor:UIColor.black]
        navigationController?.navigationBar.titleTextAttributes = textAttributes
        
        //setting up collectionview, with the spaces between the boxes being cellPadding
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumLineSpacing = cellPadding
        layout.minimumInteritemSpacing = cellPadding
        
        itemCollectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        itemCollectionView.backgroundColor = .clear
        itemCollectionView.translatesAutoresizingMaskIntoConstraints = false
        itemCollectionView.clipsToBounds = false
        itemCollectionView.register(ItemsCollectionViewCell.self, forCellWithReuseIdentifier: itemCellReuseIdentifier)
        itemCollectionView.showsVerticalScrollIndicator = false
        itemCollectionView.dataSource = self
        itemCollectionView.delegate = self
        view.addSubview(itemCollectionView)

        
        //addbutton stuff
        var addButtonFrame = addButton.frame
//           menuButtonFrame.origin.y = view.bounds.height - menuButtonFrame.height - 120
//           menuButtonFrame.origin.x = view.bounds.width/2 + 92
        addButton.frame = addButtonFrame
        addButtonFrame.origin.y = view.bounds.height - addButtonFrame.height - 100
        addButtonFrame.origin.x = view.bounds.width - 100
        addButton.frame = addButtonFrame
     //if i wanna center it
        // menuButtonFrame.origin.y = view.bounds.height - menuButtonFrame.height - 50
       //  menuButtonFrame.origin.x = view.bounds.width/2 - menuButtonFrame.size.width/2
         addButton.backgroundColor = UIColor.systemTeal
         addButton.layer.cornerRadius = addButtonFrame.height/2
         addButton.layer.shadowColor = UIColor.black.cgColor
         addButton.layer.shadowOffset = CGSize(width: 0, height: 0)
         addButton.layer.shadowRadius = 10.0
         addButton.layer.shadowOpacity = 0.5
         addButton.layer.masksToBounds = false
         addButton.addTarget(self, action: #selector(addButtonTapped), for: .touchUpInside)
         addButton.setImage(UIImage(systemName: "plus", withConfiguration: UIImage.SymbolConfiguration(pointSize: 50, weight: .medium)), for: .normal)
         addButton.tintColor = .white
        view.addSubview(addButton)
        
        setupConstraints()


    }
    
    //constraints
    func setupConstraints() {
        let collectionViewPadding: CGFloat = 20
        NSLayoutConstraint.activate([
            //mainTitle.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor, constant: 0),
            //mainTitle.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 0),
            itemCollectionView.topAnchor.constraint(equalTo: view.topAnchor, constant: 0),
            itemCollectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: cellPadding),
            itemCollectionView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: 0),
            itemCollectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -cellPadding),
            
        ])
    }
    
    //scrolling animation
    func scrollViewWillBeginDecelerating(_ scrollView: UIScrollView) {
        
        if scrollView.panGestureRecognizer.translation(in: scrollView).y < 0 {
        setTabBarHidden(stuff: tabBarController?.tabBar ?? UIView(), hidden: true)
//        setTabBarHidden(stuff: addButton, hidden: true)
            print("here")
            UIView.animate(withDuration: 0.5) {
                if (self.addButton.center.y < self.view.frame.height - 100) {
                    self.addButton.center.y = self.addButton.center.y + 80
                }
            }
        
        
    } else {
        setTabBarHidden(stuff: tabBarController?.tabBar ?? UIView(), hidden: false)
        setTabBarHidden(stuff: addButton, hidden: false)
        print("there")
        UIView.animate(withDuration: 0.5) {
            if (self.addButton.center.y > self.view.frame.height - 100) {
                self.addButton.center.y = self.addButton.center.y - 80
            }
        }
    }
        
    }
    
    
    //method that conforms to UISearchResultsUpdating
    func updateSearchResults(for searchController: UISearchController) {
        guard let text = searchController.searchBar.text else{
            return
        }
        print(text)

    }
    
    //stuff that happens when the button is tapped
    @objc private func addButtonTapped(sender:UIButton) {
        self.animateView(sender)
        HapticsManager.shared.vibrate(for: .success)
        let vc = AddFoundViewController()
        vc.delegate = self
        navigationController?.pushViewController(vc, animated: true)
    }
    
    //animation
    func animateView(_ viewToAnimate:UIView){
        UIView.animate(withDuration: 0.05, delay: 0, usingSpringWithDamping: 0.2, initialSpringVelocity: 0.5, options: .curveEaseIn, animations: {
            
            viewToAnimate.transform = CGAffineTransform(scaleX: 0.92, y:0.92)
        }) { (_) in
            UIView.animate(withDuration: 0.05, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 2, options: .curveEaseIn, animations: {
                viewToAnimate.transform = CGAffineTransform(scaleX: 1, y:1)
            }, completion: nil)
        }
    }
}
    
    extension ItemsViewController: UICollectionViewDataSource {
        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: itemCellReuseIdentifier, for: indexPath) as! ItemsCollectionViewCell
                
            var item: Item

            item = items[indexPath.item]
                cell.configure(for: item)
                return cell
                
        }
        
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return items.count
        }
    }
    
        extension ItemsViewController: UICollectionViewDelegateFlowLayout, UICollectionViewDelegate {

            func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
                let item = items[indexPath.item]
                if let cell = collectionView.cellForItem(at: indexPath) as? ItemsCollectionViewCell {
                    let vc = SpecificItemViewController(item: item)
                    vc.view.backgroundColor = .white
                    //vc.delegate = self
                    navigationController?.pushViewController(vc, animated: true)
                    
                }
            }
            func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
                
                if (collectionView == itemCollectionView) {
                    let numItemsPerRow: CGFloat = 2.0
                    let size = (collectionView.frame.width - cellPadding) / numItemsPerRow
                    return CGSize(width: size, height: size*1.4)
                } else {
                    let fatness = 150
                    let tallness = 35
                    return CGSize(width: fatness, height: tallness)
                }
                
            }
            
            

        }


        extension ItemsViewController: AddFoundDelegate {
            func didAddFoundItem(item: Item) {
                items.append(item)
                itemCollectionView.reloadData()
            }
        }

//scrolling animation pt 2
extension ItemsViewController  {
    func setTabBarHidden(stuff: UIView, hidden: Bool, animated: Bool = true, duration: TimeInterval = 0.3) {
        if stuff.isHidden != hidden{
            if animated {
                if (stuff.isHidden){
                    stuff.isHidden = hidden
                }
                let frame = stuff.frame
                    let factor: CGFloat = hidden ? 1 : -1
                    let y = frame.origin.y + (frame.size.height * factor)
                    UIView.animate(withDuration: duration, animations: {
                        stuff.frame = CGRect(x: frame.origin.x, y: y, width: frame.width, height: frame.height)
                    }) {(bool) in
                        if (!stuff.isHidden){
                            stuff.isHidden = hidden
                        }
                    }
            }
        }
    }
}

    
