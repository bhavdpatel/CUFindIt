//
//  ViewController.swift
//  CUFindit Final
//
//  Created by Liam Du on 12/3/21.
//
import UIKit

class TabBarViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.dismiss(animated: true, completion: nil)
        let vc1 = ItemsViewController()
        let vc2 = ProfileVC()
        let vc3 = AddFoundViewController()
        
        vc1.title = "CUFindit"
        
        vc2.title = "Hello, Liam"
        
        vc3.title = "What did you find?"
        
        
        vc1.navigationItem.largeTitleDisplayMode = .always
        vc2.navigationItem.largeTitleDisplayMode = .always
        vc3.navigationItem.largeTitleDisplayMode = .always
        
        let nav1 = UINavigationController(rootViewController: vc1)
        let nav2 = UINavigationController(rootViewController: vc2)
        let nav3 = UINavigationController(rootViewController: vc3)
        
        nav1.tabBarItem = UITabBarItem(title: "Lists", image: UIImage(systemName: "magnifyingglass.circle"), tag: 1)
        nav2.tabBarItem = UITabBarItem(title: "Profile", image: UIImage(systemName: "person.crop.circle"), tag: 1)
        


        nav1.navigationBar.prefersLargeTitles = true
        nav2.navigationBar.prefersLargeTitles = true
        nav3.navigationBar.prefersLargeTitles = true
        
        setViewControllers([nav1, nav2], animated: true)

        // Do any additional setup after loading the view.
    }

}
