//
//  AddFoundViewController.swift
//  CU Find it!
//
//  Created by Richard Gu on 11/21/21.
//

import UIKit

protocol AddFoundDelegate {
    func didAddFoundItem(item: Item)
}
class AddFoundViewController: UIViewController {
    var delegate: AddFoundDelegate?
    let mainTitle = UILabel()
    let nameLabel = UILabel()
    let inputName = UITextField()
    let categoryLabel = UILabel()
    let inputCategory = UITextField()
    let locationLabel = UILabel()
    let inputLocation = UITextField()
    let submitButton = UIButton(frame: CGRect(x: 0, y: 0, width: 129, height: 51))
    let categories = UILabel()
    let dateLabel = UILabel()
    let dateInput = UITextField()
    let imageLabel = UILabel()
    let imageName = UITextField()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        
        self.title = "What did you find?"
        self.navigationItem.largeTitleDisplayMode = .always
        
        self.navigationController?.navigationBar.tintColor = UIColor.black


        
        mainTitle.text = "Add a found item"
        mainTitle.textColor = .clear
        
        mainTitle.font = .systemFont(ofSize: 18, weight: .black)
        mainTitle.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(mainTitle)
        
        nameLabel.text = "Item name"
        nameLabel.textColor = .black
        
        nameLabel.font = .systemFont(ofSize: 18, weight: .medium)
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(nameLabel)
        
        inputName.placeholder = "Enter item name here "
        inputName.font = .systemFont(ofSize: 18, weight: .medium)
        inputName.textAlignment = .left
        inputName.textColor = .blue
        inputName.adjustsFontSizeToFitWidth = false
        inputName.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(inputName)
        
        categoryLabel.text = "Category"
        categoryLabel.textColor = .black
        
        categoryLabel.font = .systemFont(ofSize: 18, weight: .medium)
        categoryLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(categoryLabel)
        
        inputCategory.placeholder = "Enter item category here "
        inputCategory.font = .systemFont(ofSize: 18, weight: .medium)
        inputCategory.textAlignment = .left
        inputCategory.textColor = .blue
        inputCategory.adjustsFontSizeToFitWidth = false
        inputCategory.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(inputCategory)
        
        locationLabel.text = "Location Found"
        locationLabel.textColor = .black
        
        locationLabel.font = .systemFont(ofSize: 18, weight: .medium)
        locationLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(locationLabel)
        
        inputLocation.placeholder = "Enter item location here "
        inputLocation.font = .systemFont(ofSize: 18, weight: .medium)
        inputLocation.textAlignment = .left
        inputLocation.textColor = .blue
        inputLocation.adjustsFontSizeToFitWidth = false
        inputLocation.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(inputLocation)
        
        submitButton.setTitle("Save", for: .normal)
        submitButton.backgroundColor = .systemTeal
        submitButton.setTitleColor(.white, for: .normal)
        
        var claimButtonFrame = submitButton.frame
        submitButton.frame = claimButtonFrame
        claimButtonFrame.origin.y = view.bounds.height - claimButtonFrame.height - 100
        claimButtonFrame.origin.x = view.bounds.width/2 - claimButtonFrame.size.width/2
        submitButton.frame = claimButtonFrame
     
     //if i wanna center it
        // menuButtonFrame.origin.y = view.bounds.height - menuButtonFrame.height - 50
        
        submitButton.backgroundColor = UIColor.systemTeal
        submitButton.layer.cornerRadius = claimButtonFrame.height/2
        submitButton.layer.shadowColor = UIColor.black.cgColor
        submitButton.layer.shadowOffset = CGSize(width: 0, height: 0)
        submitButton.layer.shadowRadius = 10.0
        submitButton.layer.shadowOpacity = 0.5
        submitButton.layer.masksToBounds = false
       
        submitButton.addTarget(self, action: #selector(buttonClosed), for: .touchUpInside)
        view.addSubview(submitButton)
        //when user clicks save button, write delegate?.didAddItem([insert item])
        
        categories.text = "Item categories include: socks, briefcase,\nheadphones, backpack, airpods, wallet, iphone, \nand other. If your item is not included in \nthis list, select the closest category \nand provide more detail in the name."

        categories.adjustsFontSizeToFitWidth = false
        categories.numberOfLines = 0
        categories.font = .systemFont(ofSize: 14, weight: .semibold)
        categories.textAlignment = .natural
        categories.textColor = .systemTeal
        categories.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(categories)
        
        inputName.placeholder = "Enter item name here "
        inputName.font = .systemFont(ofSize: 18, weight: .semibold)
        inputName.textAlignment = .left
        inputName.textColor = .blue
        inputName.adjustsFontSizeToFitWidth = false
        inputName.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(inputName)
        
        dateLabel.font = .systemFont(ofSize: 18, weight: .semibold)
        dateLabel.textAlignment = .left
        dateLabel.textColor = .blue
        dateLabel.adjustsFontSizeToFitWidth = false
        dateLabel.translatesAutoresizingMaskIntoConstraints = false
        dateInput.placeholder = "Enter date in format dd/mm/yy"
        

        NSLayoutConstraint.activate([
//            mainTitle.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor, constant: 0),
//            mainTitle.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 0),
            nameLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
            nameLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            
            inputName.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
            inputName.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 10),
            
            categoryLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 5),
            categoryLabel.topAnchor.constraint(equalTo: inputName.bottomAnchor, constant: 20),

            inputCategory.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
            inputCategory.topAnchor.constraint(equalTo: categoryLabel.bottomAnchor, constant: 10),
            
            categories.topAnchor.constraint(equalTo: inputCategory.bottomAnchor, constant: 10),
            categories.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),

            locationLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
            locationLabel.topAnchor.constraint(equalTo: categories.bottomAnchor, constant: 20),

            inputLocation.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
            inputLocation.topAnchor.constraint(equalTo: locationLabel.bottomAnchor, constant: 10),

//            dateLabel.topAnchor.constraint(equalTo: inputLocation.bottomAnchor, constant: 20),
//            dateLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
//            dateInput.topAnchor.constraint(equalTo: dateLabel.bottomAnchor, constant: 20),
//            dateInput.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),

//            submitButton.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor, constant: 0),
//            submitButton.topAnchor.constraint(equalTo: inputLocation.bottomAnchor, constant: 10),
            
//            categories.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
//            categories.topAnchor.constraint(equalTo: submitButton.bottomAnchor, constant: 20),
            
        ])
    }
    

    @objc private func buttonClosed() {
        let formatter = DateFormatter()
        formatter.dateFormat = "MM/dd/yyyy"
        let date = formatter.string(from: Date())
        if (inputName.text == "" || inputCategory.text == "" || inputLocation.text == "") {
            // Show a UIAlertViewController
            var alert = UIAlertController(title: "Invalid input", message: "Please don't leave any field blank.", preferredStyle: .alert)
            HapticsManager.shared.vibrate(for: .error)
            alert.addAction(UIAlertAction(title: "Ok!", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        } else {
            if (inputCategory.text == "socks" || inputCategory.text == "briefcase" || inputCategory.text == "headphones" || inputCategory.text == "backpack" || inputCategory.text == "airpods" || inputCategory.text == "wallet" || inputCategory.text == "iphone") {
                
                
                NetworkManager.postItem(name: inputName.text ?? "", image: inputCategory.text ?? "", dateFound: date, location: inputLocation.text ?? "", idFound: "ld386") { item in
                    self.delegate?.didAddFoundItem(item: item)
                }
                
                
                HapticsManager.shared.vibrate(for: .success)
            } else {
                
                NetworkManager.postItem(name: inputName.text ?? "", image: inputCategory.text ?? "", dateFound: date, location: inputLocation.text ?? "", idFound: "ld386") { item in
                    self.delegate?.didAddFoundItem(item: item)
                }
                
                HapticsManager.shared.vibrate(for: .success)
            }
            self.navigationController?.popViewController(animated: true)
        
            
        }
    }
}
//        if (inputName.text == "" || inputCategory.text == "" || inputLocation.text == "") {
//            // Show a UIAlertViewController
//            var alert = UIAlertController(title: "Invalid input", message: "Please don't leave any field blank.", preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: "Ok!", style: .default, handler: nil))
//            self.present(alert, animated: true, completion: nil)
//        } else {
//            delegate?.didAddFoundItem(item: Item(imageName: inputCategory.text ?? "other", name: inputName.text ?? "None", location: inputLocation.text ?? "None"))
//            self.navigationController?.popViewController(animated: true)
//
//
//        }
//    }
//
//}
