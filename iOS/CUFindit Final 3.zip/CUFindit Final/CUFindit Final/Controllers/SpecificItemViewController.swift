//
//  NewestViewController.swift
//  CUFindit Dec2
//
//  Created by Richard Gu on 12/2/21.
//

import UIKit

//protocol NewUIDelegate {
//}

class SpecificItemViewController: UIViewController {
    let itemName = UILabel()
    let location = UILabel()
    let date = UILabel()
    let idFound = UILabel()
    let idClaimed = UILabel()
    
    let backgroundImage = UIImageView()
    
    let idFoundLabel = UILabel()
    let idClaimedLabel = UILabel()
    let locationFoundLabel = UILabel()
    let dateLabel = UILabel()
    
    let picture = UIImageView()
    var thing : Item?
    var claim = UIButton(frame: CGRect(x: 0, y: 0, width: 129, height: 51))
    
    init(item: Item) {
        thing = item
        super.init(nibName: nil, bundle: nil)
//        picture.contentMode = .scaleAspectFit
//        picture.translatesAutoresizingMaskIntoConstraints = false
//        view.addSubview(picture)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func configure(for item: Item) {
        picture.image = item.getImage()
        itemName.text = item.name
        location.text = "Found at " + item.location
        date.text = item.dateFound
        idFound.text = item.idFound
        idClaimed.text = item.idClaimed
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        
        picture.image = thing?.getImage()
        picture.backgroundColor = .systemBackground
        picture.contentMode = .scaleAspectFill
        picture.clipsToBounds = true
        picture.layer.cornerRadius = 0
        picture.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(picture)
        
        itemName.text = thing?.name
        itemName.textColor = .black
        itemName.font = .systemFont(ofSize: 25, weight: .bold)
        itemName.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(itemName)
        
        idFoundLabel.text = "Found by"
        idFoundLabel.textColor = .systemTeal
        idFoundLabel.font = .systemFont(ofSize: 13, weight: .medium)
        idFoundLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(idFoundLabel)
        
        idFound.text = thing?.idFound
        idFound.textColor = .black
        idFound.font = .systemFont(ofSize: 17, weight: .medium)
        idFound.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(idFound)
        
        idClaimedLabel.text = "Claimed by"
        idClaimedLabel.font = .systemFont(ofSize: 13, weight: .medium)
        idClaimedLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(idClaimedLabel)
        
        //claim check
        if (thing?.idClaimed == ""){
            idClaimed.text = ""
            idClaimedLabel.textColor = .gray
        }else{
            idClaimed.text = thing?.idClaimed
            idClaimedLabel.textColor = .systemTeal

        }
        idClaimed.textColor = .black
        idClaimed.font = .systemFont(ofSize: 17, weight: .medium)
        idClaimed.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(idClaimed)
        
        locationFoundLabel.text = "Location found"
        locationFoundLabel.textColor = .systemTeal
        locationFoundLabel.font = .systemFont(ofSize: 13, weight: .medium)
        locationFoundLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(locationFoundLabel)
        
        location.text = thing?.location
        //location.textAlignment = .center
        location.textColor = .black
        location.font = .systemFont(ofSize: 17, weight: .medium)
        location.translatesAutoresizingMaskIntoConstraints = false
        location.adjustsFontSizeToFitWidth = false
        location.numberOfLines = 0
        view.addSubview(location)
        
        dateLabel.text = "Found on"
        dateLabel.textColor = .systemTeal
        dateLabel.font = .systemFont(ofSize: 13, weight: .medium)
        dateLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(dateLabel)
        
        date.text = thing?.dateFound
        date.textColor = .black
        date.font = .systemFont(ofSize: 17, weight: .medium)
        date.translatesAutoresizingMaskIntoConstraints = false
        date.adjustsFontSizeToFitWidth = false
        date.numberOfLines = 0
        view.addSubview(date)
        
        claim.setTitle("Claim", for: .normal)
        claim.backgroundColor = .systemTeal
        claim.setTitleColor(.white, for: .normal)
        
        var claimButtonFrame = claim.frame
        claim.frame = claimButtonFrame
        claimButtonFrame.origin.y = view.bounds.height - claimButtonFrame.height - 100
        claimButtonFrame.origin.x = view.bounds.width/2 - claimButtonFrame.size.width/2
        claim.frame = claimButtonFrame
     
     //if i wanna center it
        // menuButtonFrame.origin.y = view.bounds.height - menuButtonFrame.height - 50
        
        claim.backgroundColor = UIColor.systemTeal
        claim.layer.cornerRadius = claimButtonFrame.height/2
        claim.layer.shadowColor = UIColor.black.cgColor
        claim.layer.shadowOffset = CGSize(width: 0, height: 0)
        claim.layer.shadowRadius = 10.0
        claim.layer.shadowOpacity = 0.5
        claim.layer.masksToBounds = false
       
        view.addSubview(claim)
        
        claim.addTarget(self, action: #selector(self.buttonTapped), for: .touchUpInside)

        
        NSLayoutConstraint.activate([
        picture.topAnchor.constraint(equalTo: view.topAnchor, constant: 0),
        picture.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0),
        picture.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 0),
        picture.heightAnchor.constraint(equalToConstant: view.frame.height/2),
        
        
        itemName.topAnchor.constraint(equalTo: picture.bottomAnchor, constant: 20),
        itemName.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
        
        idFoundLabel.topAnchor.constraint(equalTo: itemName.bottomAnchor, constant: 10),
        idFoundLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
        
        idFound.topAnchor.constraint(equalTo: idFoundLabel.bottomAnchor, constant: 5),
        idFound.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
        
        idClaimedLabel.topAnchor.constraint(equalTo: itemName.bottomAnchor, constant: 10),
        idClaimedLabel.leadingAnchor.constraint(equalTo: idFoundLabel.trailingAnchor, constant: 20),
        
        idClaimed.topAnchor.constraint(equalTo: idClaimedLabel.bottomAnchor, constant: 5),
        idClaimed.leadingAnchor.constraint(equalTo: idFoundLabel.trailingAnchor, constant: 20),

        locationFoundLabel.topAnchor.constraint(equalTo: idFound.bottomAnchor, constant: 30),
        locationFoundLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
        
        location.topAnchor.constraint(equalTo: locationFoundLabel.bottomAnchor, constant: 5),
        location.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
        
        dateLabel.topAnchor.constraint(equalTo: location.bottomAnchor, constant: 30),
        dateLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),

        date.topAnchor.constraint(equalTo: dateLabel.bottomAnchor, constant: 5),
        date.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),

        
//        picture.topAnchor.constraint(equalTo: location.bottomAnchor, constant: 5),
//        picture.heightAnchor.constraint(equalToConstant: 80),
//        picture.widthAnchor.constraint(equalToConstant: 80),
//        picture.trailingAnchor.constraint(equalTo: location.leadingAnchor, constant: -10),
//        picture.bottomAnchor.constraint(equalTo: view.bottomAnchor),
        
        
        claim.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor, constant: 0),
        claim.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 330)
        
        ])
        
    }
    
    @objc private func buttonTapped(sender:UIButton) {
        //self.navigationController?.popViewController(animated: true)
        self.animateView(sender)

        if (idClaimed.text == ""){
            HapticsManager.shared.vibrate(for: .success)

            //placeholder, change this to network stuff (authentication and input whatever the netid of the user logged in is)
            thing?.idClaimed = "ld386"
            idClaimed.text = thing?.idClaimed
            idClaimedLabel.textColor = .systemTeal
            claim.backgroundColor = UIColor.lightGray
            claim.setTitle("Claimed", for: .normal)
            //update claimed item
        }else{
            HapticsManager.shared.vibrate(for: .warning)

            //placeholder, after this u gotta send a request to server to delete
            thing?.idClaimed = ""
            idClaimed.text = thing?.idClaimed
            idClaimedLabel.textColor = .gray
            claim.backgroundColor = UIColor.systemTeal
            claim.setTitle("Claim", for: .normal)
        }
        
    }
    
    func animateView(_ viewToAnimate:UIView){
        UIView.animate(withDuration: 0.05, delay: 0, usingSpringWithDamping: 0.2, initialSpringVelocity: 0.5, options: .curveEaseIn, animations: {
            
            viewToAnimate.transform = CGAffineTransform(scaleX: 0.92, y:0.92)
        }) { (_) in
            UIView.animate(withDuration: 0.05, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 2, options: .curveEaseIn, animations: {
                viewToAnimate.transform = CGAffineTransform(scaleX: 1, y:1)
            }, completion: nil)
        }
    }
    

    

}
