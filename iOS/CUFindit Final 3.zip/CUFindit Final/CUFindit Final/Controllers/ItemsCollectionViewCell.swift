//
//  ItemsCollectionViewCell.swift
//  CU Find it!
//
//  Created by Richard Gu on 11/21/21.
//

import UIKit

class ItemsCollectionViewCell: UICollectionViewCell {
    var itemImageView = UIImageView()
    var nameLabel = UILabel()
    var dateFound = UILabel()
    //var locationLabel = UILabel()
    //var lostFoundLabel = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        nameLabel.font = .systemFont(ofSize: 13, weight: .medium)
        nameLabel.textColor = .black
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.numberOfLines = 0
        
        contentView.addSubview(nameLabel)
        
        dateFound.font = .systemFont(ofSize: 13, weight: .regular)
        dateFound.textColor = .gray
        dateFound.translatesAutoresizingMaskIntoConstraints = false
        dateFound.numberOfLines = 0

        contentView.addSubview(dateFound)

        
//        locationLabel.font = .systemFont(ofSize: 14)
//        locationLabel.translatesAutoresizingMaskIntoConstraints = false
//        //contentView.addSubview(locationLabel)
//
//        lostFoundLabel.font = .systemFont(ofSize: 14)
//        lostFoundLabel.translatesAutoresizingMaskIntoConstraints = false
//        //contentView.addSubview(lostFoundLabel)

        contentView.layer.cornerRadius = 16
        contentView.clipsToBounds = true
        contentView.backgroundColor = .CUFinditGray
        
        //dropshadow
//        contentView.layer.shadowColor = UIColor.black.cgColor
//        contentView.layer.shadowOffset = CGSize(width: 0, height: 0)
//        contentView.layer.shadowRadius = 5.0
//        contentView.layer.shadowOpacity = 0.1
//        contentView.layer.masksToBounds = false
        
        //making the image curved on the top left and top right
        itemImageView.layer.cornerRadius = 16
        itemImageView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]

        itemImageView.contentMode = .scaleAspectFill
        itemImageView.clipsToBounds = true
        itemImageView.translatesAutoresizingMaskIntoConstraints = false
        
        contentView.addSubview(itemImageView)

        setupConstraints()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func configure(for item: Item) {
        itemImageView.image = item.getImage()
        nameLabel.text = item.name
        dateFound.text = item.dateFound
//        locationLabel.text = "Location: " + item.location
//        lostFoundLabel.text = item.lostOrFound
    }

    func setupConstraints() {
        let padding: CGFloat = 4
        let labelHeight: CGFloat = 20
        NSLayoutConstraint.activate([
            itemImageView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 0),
            
            //itemImageView.bottomAnchor.constraint(equalTo: locationLabel.topAnchor, constant: padding),
            itemImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            itemImageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            itemImageView.heightAnchor.constraint(equalToConstant: 180),
            
            nameLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: padding*3),
            nameLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -padding*5),
            nameLabel.topAnchor.constraint(equalTo: itemImageView.bottomAnchor, constant: padding*4),
            
            dateFound.topAnchor.constraint(equalTo: itemImageView.bottomAnchor, constant: padding*4),
            dateFound.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -padding*3)
            //nameLabel.heightAnchor.constraint(equalToConstant: labelHeight),
            
//            lostFoundLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: padding),
//            lostFoundLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -padding),
//            lostFoundLabel.heightAnchor.constraint(equalToConstant: labelHeight),
//
//            locationLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -padding),
//            locationLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -padding),
//            locationLabel.heightAnchor.constraint(equalToConstant: labelHeight)
        ])
    }
}
