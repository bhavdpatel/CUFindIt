//
//  Item.swift
//  CU Find it!
//
//  Created by Richard Gu on 11/21/21.
//

import Foundation
import UIKit

struct Item: Codable {
    var imageName: String
    var name: String
    var location: String
    var dateFound: String
    var idFound: String
    var idClaimed: String
    var id: Int

//    init (imageName: String, name: String, location: String, dateFound: String, idFound: String, idClaimed: String) {
//        self.name = name
//        self.imageName = imageName
//        self.location = location
//        self.dateFound = dateFound
//        self.idFound = idFound
//        self.idClaimed = idClaimed
//    }

    func getImage() -> UIImage {
        let imageName = imageName
        guard let image = UIImage(named: imageName) else { return UIImage() }
        return image
    }
}
