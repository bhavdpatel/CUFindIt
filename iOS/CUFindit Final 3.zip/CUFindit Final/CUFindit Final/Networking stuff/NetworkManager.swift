//
//  NetworkManager.swift
//  CUFindit Dec1
//
//  Created by Liam Du on 12/1/21.
//

import Foundation
import Alamofire

class NetworkManager {
    static let host = "https://cufinditt.herokuapp.com"
    
    static func getAllItem(completion: @escaping ([Item])-> Void) {
        //let endpoint = "\(host)/api/items/"
        let endpoint = "https://cufinditt.herokuapp.com/"
        let userInfoKey = "userInfo"
        AF.request(endpoint, method: .get).validate().responseData { response in
            switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.keyDecodingStrategy = .convertFromSnakeCase
                if let items = try? jsonDecoder.decode([Item].self, from: data){
                    completion(items)
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    static func postItem(name: String, image: String, dateFound: String, location: String, idFound: String, completion: @escaping (Item)-> Void) {
        let endpoint = "\(host)/api/item/"
        
        let parameters: Parameters = [
           "name" : name,
           "image" : image,
           "date_found" : dateFound,
           "location" : location,
           "id_found" : idFound
         ]
        
        
        AF.request(endpoint, method: .post, parameters: parameters, encoding: JSONEncoding.default).validate().responseData { response in
            debugPrint(response)
            switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.keyDecodingStrategy = .convertFromSnakeCase
                if let item = try? jsonDecoder.decode(Item.self, from: data){
                    completion(item)
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    
}
