//
//  Haptics.swift
//  CUFindit Dec1
//
//  Created by Liam Du on 12/1/21.
//

import UIKit

final class HapticsManager {
    static let shared = HapticsManager()
    
    private init(){}
    
    public func selectionVibrate() {
        DispatchQueue.main.async {
            let selectionFeedBackGenerator = UISelectionFeedbackGenerator()
            selectionFeedBackGenerator.prepare()
            selectionFeedBackGenerator.selectionChanged()
        }

    }
    
    public func vibrate (for type: UINotificationFeedbackGenerator.FeedbackType) {
        DispatchQueue.main.async {
            let notificationGenerator = UINotificationFeedbackGenerator()
            notificationGenerator.prepare()
            notificationGenerator.notificationOccurred(type)
        }
    }
}

